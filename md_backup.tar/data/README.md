# Patient Data Directory

This directory contains the **Mirrored Clinical Filesystem** used by the bot and synced via WebDAV.

## Structure (v5.6.3)

Each patient has a dedicated folder: `data/patients/{Name} ({TelegramID})/`

- `{TelegramID}.md`: **The Medical Card**. All clinical history, interactions, and notes in Markdown format.
- `scans/`: PDFs, Images of analyses/docs.
- `images/`: Clinical photos (Before/After).
- `messages/`: Voice message archives (.ogg).

## Privacy & Sync

- **WebDAV**: This folder is exposed via WebDAV for sync with **Obsidian** (Admin only).
- **Backups**: Verified nightly backups are sent to the Admin via Telegram.
- **Security**: Direct file access block.

# Design Backlog

Future design improvements for Vera Massage Bot. Low priority - to be considered when time allows.

---

## Bot Experience

### Animated Stickers

- Use custom or themed stickers for: welcome, confirmation, reminders
- Creates personality and emotional connection

### Web App Modal for Booking  

- **Concept**: Instead of inline keyboards (which push context up), clicking "Book Appointment" opens a slide-up Web View (TWA).
- **UX**: 50-75% screen height modal. Visual calendar + Service photos.
- **Benefit**: Faster than round-trip button clicks; richer presentation.
- **Status**: Backlog (User approved concept).
- **Effort**: Medium

### Typing Indicators + Delays

- Add small delays with `sendChatAction("typing")` to make bot feel more human
- **Effort**: Low

### Deep Links for Quick Actions

- Generate shareable deep links like `t.me/vera_bot?start=book_massage`
- Useful for marketing materials

---

## TWA (Patient Card)

### Progress Visualization

- Show "15 sessions over 8 months" with a mini timeline/sparkline
- Creates sense of journey and progress
- **Effort**: Medium

### Hero Gradient Header

- **Concept**: Replace stark white header with soft transition (Blue → Purple).
- **Visual**: Adds warmth and "Premium/Wellness" feel.
- **Mockup**: [Hero Gradient Concept](file:///home/kirillfilin/.gemini/antigravity/brain/17e5d488-9963-4a50-b867-5464e0e5baab/hero_gradient_mockup_1770326185689.png)
- **User Feedback**: Likes it. Asked about customization (Wallpaper vs Banner?).
- **Effort**: Medium

### Card-Based Appointments

- Each future appointment = one card with shadow
- Quick visual scan, like flight boarding passes
- **Effort**: Low-Medium

### Sticky Bottom CTA

- Pin the "countdown" banner or a "Напомнить" button to bottom of screen
- Requires iOS-safe implementation (safe-area-inset)
- **Effort**: Medium

### Custom Brand Colors

- Introduce subtle brand color palette instead of pure blue
- Consider soft coral or teal for spa/wellness feel
- **Effort**: Low

---

## Cleanup Candidates

### Empty State Visuals

- **Status**: Iteration Required.
- **Feedback**: User preferred "Minimalist Line Art" over Abstract.
- **Requirement**: Must verify Dark Mode compatibility. Need 2-3 more options in that specific style.

### File Icons

- **Status**: Iteration Required.
- **Feedback**: User liked both "Gradient" and "Line Art" directions but needs more options.
- **Requirement**: Must check Dark Mode contrast (dark grey line art might vanish on dark backgrounds).

| Element | Status | Notes |
| ------- | ------ | ----- |
| "Bot Version" in footer | Keep for now | Shows professionalism |
| "Professional Medical Record Hub" | **Replace** | Generic branding. User rejects "Health Space"/"Wellness Hub". **Agreed Direction**: "Personal Cabinet" (Личный Кабинет) best fits the medical/rehab focus. |

---

## Strategic Alignment (Resolved 2026-02-06)

1. **Goal**: Hybrid (History for retention + Rebooking for business).
2. **Focus**: First Impressions (Empty States) are critical as we are in Test Mode (no real patients yet).
3. **Icons**: No generic (ICQ/Notion style) icons. Custom only.
4. **Naming**: "Personal Cabinet" > "Health Space".

*Verified for v5.6.3 (Stable)*
